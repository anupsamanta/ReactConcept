export default class Network {
   static baseUrl = 'https://mnkdrona-apim.azure-api.net/PatientApp/Live/'; 
}