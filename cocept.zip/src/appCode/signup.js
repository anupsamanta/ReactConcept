import React from 'react'
import { View, Text} from 'react-native'

export default function signup() {
  return (
    <View>
        <Text>Signup</Text>
    </View>
  )
}
