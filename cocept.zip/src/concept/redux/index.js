export {fetchDoctorProfileHeaderWatcher} from './doctorProfileSaga';

export {doctorProfileSelector} from './doctorProfileSelector';

export {

  doctorProfileActions, //4 Action Export
  doctorProfileReducer,//3 // Reducer export
 // fetchDoctorProfileDataTypeName, //2 Action Type Name
 // fetchDoctorProfileDataCreater, // 1 Action Name
} from './doctorProfileSlice';
